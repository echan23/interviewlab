import React from "react";
import CodeEditor from "./components/CodeEditor";
import Output from "./components/Output";
import { Panel, PanelGroup, PanelResizeHandle } from "react-resizable-panels";
import Header from "./components/Header";
import { useState, useRef } from "react";
import * as monaco from "monaco-editor";

function App() {
  const editorRef = useRef<monaco.editor.IStandaloneCodeEditor | null>(null);
  /*The editor useState is at the top level and we use a prop to pass it to CodeEditor. 
  This way, CodeEditor can update the editor value without having to pass it as a prop.
  Another option is to pass the editor value as a prop and update it in the CodeEditor component,
  but this is bad practice because you don't want to use the editor for state management.
  */
  const [editorValue, setEditorValue] = useState("");

  return (
    <div className="app-container h-screen w-screen flex flex-col overflow-hidden">
      <Header />

      <div className="code-section-container rounded-lg border border-gray-300 m-1 p-1">
        <div className="flex-1">
          <PanelGroup direction="horizontal">
            <Panel defaultSize={70} minSize={20}>
              <div className="h-full overflow-auto">
                <CodeEditor
                  editorRef={editorRef}
                  value={editorValue}
                  onChange={(newValue) => setEditorValue(newValue)}
                />
              </div>
            </Panel>
            {/* Resizable Divider */}
            <PanelResizeHandle className="w-1 bg-gray-400 hover:bg-gray-600 cursor-col-resize transition-colors duration-150 ml-1 mr-1" />
            <Panel defaultSize={30} minSize={20}>
              <div className="output-container-wrapper h-full overflow-auto flex flex-col justify-end">
                <Output input={editorValue} />
              </div>
            </Panel>
          </PanelGroup>
        </div>
      </div>
    </div>
  );
}

export default App;
