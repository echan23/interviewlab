const languageTemplates: { [key: string]: string } = {
  python: `#Nice and simple!`,

  java: `//Old reliable ...`,

  c: `How about a classic?`,

  cpp: `A true chad.`,

  javascript: `Why?!`,
};

export default languageTemplates;
